package com.example.wordguessinggame;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;



public class LeaderboardActivity extends AppCompatActivity {

    private ListView leaderboardListView;
    private ArrayList<PlayerScore> leaderboardData;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);

        leaderboardListView = findViewById(R.id.leaderboardListView);
        leaderboardData = new ArrayList<>();

        // Fetch leaderboard data (replace this with actual API call or database query)
        fetchLeaderboardData();

        // Sort the leaderboard data by score in descending order
        Collections.sort(leaderboardData, new Comparator<PlayerScore>() {
            @Override
            public int compare(PlayerScore p1, PlayerScore p2) {
                return Integer.compare(p2.getScore(), p1.getScore());
            }
        });

        // Create a custom adapter to display the leaderboard data
        LeaderboardAdapter adapter = new LeaderboardAdapter(this, leaderboardData);
        leaderboardListView.setAdapter(adapter);
    }

    private void fetchLeaderboardData() {
        // In a real application, you would fetch this data from a server or local database
        // For this example, we'll add some dummy data
        leaderboardData.add(new PlayerScore("Alice", 100));
        leaderboardData.add(new PlayerScore("Bob", 85));
        leaderboardData.add(new PlayerScore("Charlie", 95));
        leaderboardData.add(new PlayerScore("David", 75));
        leaderboardData.add(new PlayerScore("Eve", 90));
    }

    // PlayerScore class to hold player data
    private static class PlayerScore {
        private String name;
        private int score;

        public PlayerScore(String name, int score) {
            this.name = name;
            this.score = score;
        }

        public String getName() {
            return name;
        }

        public int getScore() {
            return score;
        }
    }


    // Custom adapter for the leaderboard
    private static class LeaderboardAdapter extends ArrayAdapter<PlayerScore> {
        public LeaderboardAdapter(LeaderboardActivity context, ArrayList<PlayerScore> players) {
            super(context, 0, players);
        }

        @Override
        public android.view.View getView(int position, android.view.View convertView, android.view.ViewGroup parent) {
            PlayerScore player = getItem(position);

            if (convertView == null) {
                convertView = android.view.LayoutInflater.from(getContext()).inflate(android.R.layout.simple_list_item_2, parent, false);
            }

            android.widget.TextView nameTextView = convertView.findViewById(android.R.id.text1);
            android.widget.TextView scoreTextView = convertView.findViewById(android.R.id.text2);

            nameTextView.setText(player.getName());
            scoreTextView.setText("Score: " + player.getScore());

            return convertView;
        }
    }
}