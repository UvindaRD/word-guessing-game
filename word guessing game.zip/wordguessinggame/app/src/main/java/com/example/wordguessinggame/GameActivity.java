package com.example.wordguessinggame;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;



public class GameActivity extends AppCompatActivity {
    String secretWord;
    int score = 100;
    int guessesLeft = 10;
    TextView scoreView, guessesView, wordHintView;
    EditText guessInput;
    Button guessBtn, hintBtn, leaderboardBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        scoreView = findViewById(R.id.scoreView);
        guessesView = findViewById(R.id.guessesView);
        wordHintView = findViewById(R.id.wordHintView);
        guessInput = findViewById(R.id.guessInput);
        guessBtn = findViewById(R.id.guessBtn);
        hintBtn = findViewById(R.id.hintBtn);
        leaderboardBtn = findViewById(R.id.leaderboardBtn);


        secretWord = getRandomWord();
        updateUI();

        guessBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String guess = guessInput.getText().toString().toLowerCase();
                checkGuess(guess);
                updateUI();
            }
        });

        hintBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score -= 20;
                provideHint();
                updateUI();
            }
        });

        leaderboardBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLeaderboard();
            }
        });

        startTimer();
    }

    private void openLeaderboard() {
        Intent intent = new Intent(GameActivity.this, LeaderboardActivity.class);
        startActivity(intent);
    }

    @SuppressLint("SetTextI18n")
    private void checkGuess(String guess) {
        if (guess.equals(secretWord)) {
            wordHintView.setText("Correct! The word is: " + secretWord);
            resetGame();
        } else {
            guessesLeft--;
            score -= 10;
            if (guessesLeft == 0) {
                wordHintView.setText("You failed! The word was: " + secretWord);
                resetGame();
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private void provideHint() {
        // Example hint logic
        wordHintView.setText("Hint: The word starts with " + secretWord.charAt(0));
    }

    @SuppressLint("SetTextI18n")
    private void updateUI() {
        scoreView.setText("Score: " + score);
        guessesView.setText("Guesses Left: " + guessesLeft);
    }

    private void resetGame() {
        secretWord = getRandomWord();  // Fetch new word from API
        guessesLeft = 10;
        score = 100;
        updateUI();
    }

    private String getRandomWord() {
        // Example word for testing
        String[] words = {"anticrime","anticrime", "beim", "chime", "climb", "clothestime", "crime", "dime", "grime",  "classy", "stylish", "simple", "tasteful", "glorious", "proud", "royal", "superb", "regal", "refined", "rich",};
        return words[new Random().nextInt(words.length)];
    }

    private void startTimer() {
        new CountDownTimer(60000, 1000) {
            @SuppressLint("SetTextI18n")
            public void onTick(long millisUntilFinished) {
                wordHintView.setText("Time left: " + millisUntilFinished / 1000);
            }
            @SuppressLint("SetTextI18n")
            public void onFinish() {
                wordHintView.setText("Time up!");
                resetGame();
            }
        }.start();
    }
}